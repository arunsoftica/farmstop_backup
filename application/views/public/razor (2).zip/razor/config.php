<?php

$keyId = 'rzp_live_7kVmu45O4Pnby9';
$keySecret = '9hdb5gPMkYJz8br70J02kZbl';
/*$keyId = 'rzp_test_aZ0BjoO5EsKzEl';
$keySecret = 'clO0v5dwplsl1ps6KLLVinqy';*/
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
